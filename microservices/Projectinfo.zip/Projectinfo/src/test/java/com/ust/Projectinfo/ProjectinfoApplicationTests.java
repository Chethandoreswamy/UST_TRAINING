package com.ust.Projectinfo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjectinfoApplicationTests {

	@Test
	void contextLoads() {
	}

}
