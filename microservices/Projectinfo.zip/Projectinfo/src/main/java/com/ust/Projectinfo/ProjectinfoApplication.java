package com.ust.Projectinfo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjectinfoApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjectinfoApplication.class, args);
	}

}
