package com.ust.Employeeinfo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeinfoApplicationTests {

	@Test
	void contextLoads() {
	}

}
