package com.ust.Employeeinfo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployeeinfoApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmployeeinfoApplication.class, args);
	}

}
